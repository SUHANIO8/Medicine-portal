import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            The Right Medicine Saves Lives
          </h1>
          <p className="mt-6 max-w-3xl mx-auto text-xl text-gray-600">
            Ensuring proper medication management is crucial for patient safety and effective treatment.
          </p>
          <div className="mt-10 flex justify-center gap-4">
            <Link
              to="/register"
              className="px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10"
            >
              Get Started
            </Link>
            <Link
              to="/login"
              className="px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 md:py-4 md:text-lg md:px-10"
            >
              Login
            </Link>
          </div>
        </div>
      </header>

      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Medication Safety",
                description: "Reduce errors with proper medication management",
                icon: "💊"
              },
              {
                title: "Patient Care",
                description: "Improve treatment outcomes with accurate prescriptions",
                icon: "❤️"
              },
              {
                title: "Digital Tracking",
                description: "QR-based system for easy medicine verification",
                icon: "📱"
              }
            ].map((feature) => (
              <div key={feature.title} className="bg-white p-6 rounded-lg shadow">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-medium text-gray-900">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
